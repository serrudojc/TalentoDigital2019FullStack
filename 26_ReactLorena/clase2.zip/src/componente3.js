import React from 'react';


export default class Componente3 extends React.Component {

    render() {
        return <div>{this.props.articulo}</div>;

    }

}