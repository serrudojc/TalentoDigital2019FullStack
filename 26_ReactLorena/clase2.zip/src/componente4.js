import React from 'react';

export default class Componente4 extends React.Component {

    render(){

    return <h1>Hola {this.props.nombre}</h1>
    }
}