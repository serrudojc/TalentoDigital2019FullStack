import React from 'react';


export default class Componente1 extends React.Component {

    render() {

        return <div>
           <img src={this.props.imagen} alt="gatitoEsperando"></img>
       </div>;
    }

}




