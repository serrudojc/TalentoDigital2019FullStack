import React from 'react';


export default class Componente2 extends React.Component {

    render() {
        return <div>{this.props.titulo}</div>;
    }

}