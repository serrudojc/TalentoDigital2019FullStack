import React from 'react';
import axios from 'axios';

export default class Componente2 extends React.Component {
    state={
        listado:[]
    }


    async componentDidMount(){
        var respuesta = await axios.get('https://jsonplaceholder.typicode.com/comments');

        if(respuesta.status===200){
            this.setState({
                listado: respuesta.data
            });
    
    
        }


    }

    render(){
        var listaMostrar=[];

        this.state.listado.forEach(function(item){
            listaMostrar.push(
                <h2>{item.name}</h2>
            );
        });

        return(
            <>
            {listaMostrar}
            </>
        );
    }
}