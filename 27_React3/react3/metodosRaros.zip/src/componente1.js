import React from 'react';

export default class Componente1 extends React.Component {

    componentDidMount(){
        console.log("Pase por ComponentDidMount de componente1");
    }

    render(){

        return(
           <img src='gatitoEsperando.jpg' /> 
        );
    }
}    