import React from 'react';

export default class Componente2 extends React.Component {

    render(){

        return(
            <h1>Titulo</h1>
        );
    }
}