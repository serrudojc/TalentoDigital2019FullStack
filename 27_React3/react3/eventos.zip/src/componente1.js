import React from 'react';

export default class Componente1 extends React.Component {

    render(){

        return(
           <img src='gatitoEsperando.jpg' /> 
        );
    }
}    